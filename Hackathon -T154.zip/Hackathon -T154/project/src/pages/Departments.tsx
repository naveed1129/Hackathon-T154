import React from 'react';
import DepartmentCard from '../components/DepartmentCard';
import type { Department } from '../types';

const Departments = () => {
  const departments: Department[] = [
    {
      id: '1',
      name: 'Computer Science & Engineering',
      description: 'Focusing on software development, artificial intelligence, and computer systems.',
    },
    {
      id: '2',
      name: 'Electronics & Communication',
      description: 'Specializing in electronic systems, communication technology, and signal processing.',
    },
    {
      id: '3',
      name: 'Mechanical Engineering',
      description: 'Dealing with design, manufacturing, and maintenance of mechanical systems.',
    },
    // Add more departments as needed
  ];

  const handleDepartmentClick = (id: string) => {
    console.log(`Clicked department ${id}`);
    // Handle navigation to department detail page
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Departments</h1>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
          Add Department
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departments.map((department) => (
          <DepartmentCard
            key={department.id}
            department={department}
            onClick={handleDepartmentClick}
          />
        ))}
      </div>
    </div>
  );
};

export default Departments;