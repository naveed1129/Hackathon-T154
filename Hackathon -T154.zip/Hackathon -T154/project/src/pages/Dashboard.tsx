import React from 'react';
import { Briefcase, Users, Award, TrendingUp } from 'lucide-react';
import MetricsChart from '../components/MetricsChart';

const Dashboard = () => {
  const statsData = [
    { title: 'Total Departments', value: '15', icon: Briefcase, color: 'bg-blue-500' },
    { title: 'Total Faculty', value: '450', icon: Users, color: 'bg-green-500' },
    { title: 'Achievements', value: '120', icon: Award, color: 'bg-purple-500' },
    { title: 'Research Papers', value: '250', icon: TrendingUp, color: 'bg-red-500' },
  ];

  const performanceData = [
    { name: 'CSE', value: 85 },
    { name: 'ECE', value: 78 },
    { name: 'ME', value: 82 },
    { name: 'Civil', value: 75 },
    { name: 'EEE', value: 80 },
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-gray-900">Institute Overview</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsData.map((stat) => (
          <div key={stat.title} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className={`${stat.color} p-3 rounded-full`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MetricsChart 
          data={performanceData}
          dataKey="value"
          title="Department Performance"
        />
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-4 text-gray-800">Recent Achievements</h3>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="border-l-4 border-indigo-500 pl-4">
                <p className="font-medium text-gray-800">Achievement Title {i}</p>
                <p className="text-sm text-gray-600">Brief description of the achievement...</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;