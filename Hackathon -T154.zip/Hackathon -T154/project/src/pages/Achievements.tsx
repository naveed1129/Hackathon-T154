import React from 'react';
import { Award, User, Calendar } from 'lucide-react';

const Achievements = () => {
  const achievements = [
    {
      id: 1,
      title: 'Best Research Paper Award',
      description: 'Research paper on AI applications in healthcare won national recognition',
      department: 'Computer Science',
      achiever: 'Dr. Sarah Johnson',
      date: '2024-02-15',
      category: 'faculty',
    },
    {
      id: 2,
      title: 'Innovation Challenge Winner',
      description: 'Student team developed sustainable energy solution',
      department: 'Mechanical Engineering',
      achiever: 'Team EcoTech',
      date: '2024-03-01',
      category: 'student',
    },
    // Add more achievements as needed
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Achievements</h1>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
          Add Achievement
        </button>
      </div>

      <div className="space-y-6">
        {achievements.map((achievement) => (
          <div key={achievement.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-start">
              <Award className="h-12 w-12 text-indigo-600 flex-shrink-0" />
              <div className="ml-4 flex-grow">
                <h3 className="text-xl font-semibold text-gray-800">{achievement.title}</h3>
                <p className="text-gray-600 mt-1">{achievement.description}</p>
                <div className="mt-4 flex flex-wrap gap-4">
                  <div className="flex items-center">
                    <User className="h-5 w-5 text-gray-500" />
                    <span className="ml-1 text-sm text-gray-600">{achievement.achiever}</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-gray-500" />
                    <span className="ml-1 text-sm text-gray-600">{achievement.date}</span>
                  </div>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    {achievement.department}
                  </span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    {achievement.category}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Achievements;