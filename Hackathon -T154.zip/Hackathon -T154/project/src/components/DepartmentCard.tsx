import React from 'react';
import { Building2, Users, BookOpen, FlaskRound as Flask } from 'lucide-react';
import type { Department } from '../types';

interface DepartmentCardProps {
  department: Department;
  onClick: (id: string) => void;
}

const DepartmentCard: React.FC<DepartmentCardProps> = ({ department, onClick }) => {
  return (
    <div 
      className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer"
      onClick={() => onClick(department.id)}
    >
      <div className="flex items-center mb-4">
        <Building2 className="h-8 w-8 text-indigo-600" />
        <h3 className="ml-2 text-xl font-semibold text-gray-800">{department.name}</h3>
      </div>
      <p className="text-gray-600 mb-4">{department.description}</p>
      <div className="grid grid-cols-3 gap-4">
        <div className="flex items-center">
          <Users className="h-5 w-5 text-indigo-500" />
          <span className="ml-1 text-sm text-gray-600">50 Faculty</span>
        </div>
        <div className="flex items-center">
          <BookOpen className="h-5 w-5 text-indigo-500" />
          <span className="ml-1 text-sm text-gray-600">500 Students</span>
        </div>
        <div className="flex items-center">
          <Flask className="h-5 w-5 text-indigo-500" />
          <span className="ml-1 text-sm text-gray-600">25 Labs</span>
        </div>
      </div>
    </div>
  );
};

export default DepartmentCard;