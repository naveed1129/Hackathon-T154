export interface Department {
  id: string;
  name: string;
  description: string;
}

export interface Report {
  id: string;
  departmentId: string;
  year: number;
  academicPerformance: AcademicMetrics;
  researchOutput: ResearchMetrics;
  achievements: Achievement[];
  infrastructure: InfrastructureMetrics;
}

export interface AcademicMetrics {
  averageGPA: number;
  graduationRate: number;
  studentCount: number;
  facultyCount: number;
}

export interface ResearchMetrics {
  publications: number;
  patents: number;
  fundingReceived: number;
  ongoingProjects: number;
}

export interface Achievement {
  title: string;
  description: string;
  date: string;
  category: 'student' | 'faculty' | 'department';
}

export interface InfrastructureMetrics {
  newFacilities: number;
  upgrades: number;
  maintenanceProjects: number;
  totalInvestment: number;
}