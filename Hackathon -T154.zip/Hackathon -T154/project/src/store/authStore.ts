import { create } from 'zustand';

interface AuthState {
  isAuthenticated: boolean;
  user: {
    email: string;
    name: string;
  } | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, name: string) => Promise<void>;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  user: null,
  login: async (email: string, password: string) => {
    // TODO: Implement actual authentication
    set({ isAuthenticated: true, user: { email, name: 'Test User' } });
  },
  signup: async (email: string, password: string, name: string) => {
    // TODO: Implement actual signup
    set({ isAuthenticated: true, user: { email, name } });
  },
  logout: () => {
    set({ isAuthenticated: false, user: null });
  },
}));